package net.enelson.astract.datacacher;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import net.enelson.astract.datacacher.api.PlaceholderExtention;
import net.enelson.astract.datacacher.configs.ConfigManager;
import net.enelson.astract.datacacher.data.DataManager;
import net.enelson.astract.datacacher.database.SQLManager;

public class ADataCacher extends JavaPlugin implements CommandExecutor {
	private ConfigManager configs;
	private static ADataCacher plugin;
	private DataManager manager;
	private SQLManager sql;
	
	public void onEnable() {
		plugin = this;
		this.configs = new ConfigManager(this);
		this.sql = new SQLManager(this);
		this.manager = new DataManager(this);
		
		if (getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
			new PlaceholderExtention().register();
		}
	}
	
	public static ADataCacher getInstance() {
		return plugin;
	}
	
	public DataManager getDataManager() {
		return this.manager;
	}
	
	public ConfigManager getConfigs() {
		return this.configs;
	}
	
	public SQLManager getSQLManager() {
		return this.sql;
	}
	

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		if(!sender.isOp())
			return true;
		
		if(args.length > 0 && args[0].equals("reload")) { //acrates reload
			this.configs.reloadConfigs();
			sender.sendMessage("The plugin has been reloaded.");
			return false;
		}
		
		return true;
	}
	
	public void onDisable() {
		this.manager.deInit();
	}
}
