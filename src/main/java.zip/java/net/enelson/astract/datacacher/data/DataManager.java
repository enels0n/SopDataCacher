package net.enelson.astract.datacacher.data;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map.Entry;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import me.clip.placeholderapi.PlaceholderAPI;
import net.enelson.astract.datacacher.ADataCacher;
import net.enelson.astract.datacacher.tops.Top;
import net.enelson.astract.datacacher.tops.TopElement;

public class DataManager {
    private ADataCacher plugin;
    private BukkitTask tasker;
    private HashMap<String, String> defaults;
    private HashMap<String, Top> tops = new HashMap<>();

    public DataManager(ADataCacher plugin) {
        this.plugin = plugin;

        int period = this.plugin.getConfigs().getConfigs().getInt("placeholders-update-time");
        if (period < 1)
            period = 1;

        this.tasker = Bukkit.getScheduler().runTaskTimer(plugin, this::updateData, 20 * 1, 20 * period);

        this.reloadConfigs();
    }

    private void updateData() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                for (Entry<String, String> placeholder : defaults.entrySet()) {
                    String value = PlaceholderAPI.setPlaceholders(player, placeholder.getKey());
                    // Обновляем отдельное поле в JSON для игрока
                    plugin.getSQLManager().updatePlayerDataField(player.getName(), placeholder.getKey(), value);
                }
            }
            updateTops(); // обновляем топы после обновления данных
        });
    }

    public String getDefault(String placeholder) {
        return this.defaults.get(placeholder);
    }

    public void reloadConfigs() {
        this.defaults = new HashMap<>();
        for (String fullPlaceholder : plugin.getConfigs().getConfigs().getStringList("placeholders")) {
            String placeholder = fullPlaceholder;
            String def = null;

            if (fullPlaceholder.contains("|||")) {
                int separatorIndex = fullPlaceholder.indexOf("|||");
                placeholder = fullPlaceholder.substring(0, separatorIndex);
                def = fullPlaceholder.substring(separatorIndex + 3);
            }

            this.defaults.put(placeholder, def);
        }
    }

    // Метод для обновления всех топов указанного типа
    private void updateTops() {
        for (String placeholderKey : defaults.keySet()) {
            String defValue = defaults.get(placeholderKey);
            boolean isNumericDef = defValue != null && defValue.matches("^-?\\d+(\\.\\d+)?$");
            if (!isNumericDef) {
                continue;
            }
            Top top = new Top(placeholderKey);
            try (ResultSet rs = plugin.getSQLManager().getTop10ByField(placeholderKey)) {
                int position = 1;
                while (rs != null && rs.next() && position <= 10) {
                    String player = rs.getString("player");
                    double score = rs.getDouble("value");
                    top.addElement(new TopElement(player, score));
                    position++;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            tops.put(placeholderKey, top);
        }
    }

    // Получение топа по типу
    public Top getTop(String topType) {
        return tops.get(topType);
    }

    public void deInit() {
        this.tasker.cancel();
    }
}
