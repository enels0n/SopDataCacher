package net.enelson.astract.datacacher.tops;

public class TopElement {
	private String player;
	private double score;
	
	public TopElement(String player, double score) {
		this.player = player;
		this.score = score;
	}

	public String getPlayer() {
		return this.player;
	}
	
	public double getScore() {
		return this.score;
	}
}
