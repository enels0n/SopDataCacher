package net.enelson.astract.datacacher.tops;

import java.util.HashMap;

public class Top {
	private String topType;
	private HashMap<Integer,TopElement> elements;

	public Top(String topType) {
		this.topType = topType;
		this.elements = new HashMap<Integer,TopElement>();
	}
	
	public String getTopType() {
		return this.topType;
	}
	
	public TopElement getTopElement(int position) {
		if(position >=1 && position <=10 && this.elements.containsKey(position))
			return this.elements.get(position);
		return null;
	}
	
    public void addElement(TopElement element) {
        this.elements.put(this.elements.size() + 1, element);
    }
}
