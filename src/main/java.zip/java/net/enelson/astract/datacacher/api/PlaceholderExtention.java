package net.enelson.astract.datacacher.api;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bukkit.entity.Player;

import me.clip.placeholderapi.PlaceholderAPI;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import net.enelson.astract.datacacher.ADataCacher;
import net.enelson.astract.datacacher.tops.Top;
import net.enelson.astract.datacacher.tops.TopElement;

public class PlaceholderExtention extends PlaceholderExpansion {

	private final Pattern pattern = Pattern.compile("\\{(?<player>[^}]+)\\}_\\{(?<placeholder>[^}]+)\\}");
	private final Pattern patternWithPlayerPlaceholder = Pattern.compile("\\{##(?<playerExpr>.+?)##\\}_\\{(?<placeholder>[^}]+)\\}");
	private final Pattern topNamePattern = Pattern.compile("top_\\{(?<placeholder>[^}]+)\\}_(?<pos>\\d+)_(?<field>name|value)(?:_(?<decimals>\\d))?");

	@Override
	public boolean canRegister() {
		return true;
	}

	@Override
	public String getAuthor() {
		return "E.NeLsOn";
	}

	@Override
	public String getIdentifier() {
		return "adatacacher";
	}

	@Override
	public String getPlugin() {
		return null;
	}

	@Override
	public String getVersion() {
		return "1.0.0";
	}

	@Override
	public boolean persist() {
		return true;
	}

	@Override
	public String onPlaceholderRequest(Player p, String identifier) {
	    Matcher topMatcher = topNamePattern.matcher(identifier);
	    if (topMatcher.matches()) {
	        String placeholderRaw = topMatcher.group("placeholder").trim();
	        String placeholder = "%" + placeholderRaw + "%";
	        int pos = Integer.parseInt(topMatcher.group("pos"));
	        String field = topMatcher.group("field");
	        String decimalsGroup = topMatcher.group("decimals");
	        int decimals = -1;

	        if (decimalsGroup != null) {
	            try {
	                decimals = Integer.parseInt(decimalsGroup);
	            } catch (Exception ignored) {}
	        }

	        Top top = ADataCacher.getInstance().getDataManager().getTop(placeholder);
	        if (top == null) {
	            return "-";
	        }

	        TopElement elem = top.getTopElement(pos);
	        if (elem == null) {
	            return "-";
	        }

	        if ("name".equals(field)) {
	            return elem.getPlayer();
	        } else if ("value".equals(field)) {
	            double val = elem.getScore();
	            if (decimals >= 0 && decimals <= 8) {
	                return String.format("%." + decimals + "f", val).replace(',', '.');
	            } else {
	                return String.valueOf(val);
	            }
	        }

	        return "-";
	    }

		Matcher matcher1 = pattern.matcher(identifier);
		if (matcher1.matches()) {
			String playerExpr = matcher1.group("player").trim();
			String placeholder = matcher1.group("placeholder").trim();

			String player = PlaceholderAPI.setPlaceholders(null, "%" + playerExpr + "%");
			return resolveValue(player, placeholder);
		}

		Matcher matcher2 = patternWithPlayerPlaceholder.matcher(identifier);
		if (matcher2.matches()) {
			String playerExpr = matcher2.group("playerExpr").trim();
			String player = PlaceholderAPI.setPlaceholders(null, "%" + playerExpr + "%");

			String placeholder = matcher2.group("placeholder").trim();
			return resolveValue(player, placeholder);
		}

		return "null";
	}

	private String resolveValue(String player, String placeholder) {
		String value = ADataCacher.getInstance().getSQLManager().getPlayerDataField(player, "%" + placeholder + "%");

		if (value != null) {
			return value;
		}

		String def = ADataCacher.getInstance().getDataManager().getDefault("%" + placeholder + "%");

		if (def != null) {
			return def;
		}

		return "null";
	}
}